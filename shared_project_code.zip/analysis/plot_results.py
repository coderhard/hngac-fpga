import re
import matplotlib.pyplot as plt
import os

# 1. Read the Log File (Adjust path if needed)
# log_path = "final_data.log"
# ".." means go up one level, then into "data"
log_path = os.path.join("..", "data", "final_data.log")
latencies_pass = []
latencies_block = []
trials_pass = []
trials_block = []

print(f"Reading log: {log_path}...")

try:
    with open(log_path, "r") as f:
        lines = f.readlines()
        
    trial_count = 0
    for line in lines:
        # Regex to find PASS or BLOCK and the nanoseconds
        match = re.search(r'(PASS|BLOCK).*?Time:\s+(\d+)\s+ns', line)
        if match:
            outcome = match.group(1)
            ns = int(match.group(2))
            us = ns / 1000.0  # Convert to microseconds
            
            trial_count += 1
            if outcome == "PASS":
                latencies_pass.append(us)
                trials_pass.append(trial_count)
            else:
                latencies_block.append(us)
                trials_block.append(trial_count)

    # 2. Plotting
    plt.figure(figsize=(10, 6))
    
    # Plot Passes (Green) and Blocks (Red)
    plt.scatter(trials_pass, latencies_pass, color='green', label='Authorized (Subject 1)', marker='o')
    plt.scatter(trials_block, latencies_block, color='red', label='Blocked (Subject 99)', marker='x')

    # Formatting
    plt.title('NGAC Gatekeeper Performance: Latency per Authorization Check')
    plt.xlabel('Message Sequence Number')
    plt.ylabel('Latency (microseconds)')
    plt.axhline(y=0, color='black', linewidth=1)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend()
    
    # Save
    output_file = "ngac_latency_results.png"
    plt.savefig(output_file)
    print(f"\nSuccess! Chart saved to: {output_file}")

except FileNotFoundError:
    print("Error: Could not find the log file. Make sure you ran the experiment!")
